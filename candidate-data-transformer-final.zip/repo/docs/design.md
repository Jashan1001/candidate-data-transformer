# Multi-Source Candidate Data Transformer — Design Document

**Jashanpreet Kaur** · 23BCS14043@cuchd.in · Eightfold Engineering Intern Assignment

## Pipeline

Extract (one isolated class per source: CSV, ATS JSON, GitHub, Resume) -> Normalize
(per field type: phone -> E.164, skill aliases -> canonical name, free-text
location -> structured city/region/country) -> Merge (source-priority
conflict resolution for scalars, union+dedupe for lists, provenance per
field) -> Confidence (source trust x normalization success +
multi-source agreement bonus - conflict penalty) -> Validate (internal
profile sanity check) -> Project (apply runtime OutputConfig: select,
rename via "from", per-field normalize) -> Validate (final output
actually matches what the config declared: required, type). Extractors
are deliberately "dumb" -- single responsibility, no knowledge of other
sources or of merge/confidence logic -- so a bug in one source's parsing
can never corrupt another's, and adding a new source is one new class.

## Canonical schema & normalized formats

Matches the assignment's default schema exactly (candidate_id, full_name,
emails[], phones[], location{city,region,country}, links{}, headline,
years_experience, skills[{name,confidence,sources[]}],
experience[], education[], provenance[{field,source,method,confidence,
raw_value,observed_sources}], overall_confidence). Phones: E.164 via
Google's `phonenumbers`, region-assumed if no explicit `+` (confidence
discounted accordingly, not silently treated as certain). Skills:
lower-cased canonical names via an alias map (e.g. "ReactJS"/"react.js"
-> "react"). Country: ISO-3166 alpha-2.

## Merge / conflict-resolution policy

Match key: every source is told which candidate it belongs to explicitly
(via CLI flags), not auto-detected — see Edge Cases. Scalars (full_name,
headline, years_experience, location): source-priority tie-break, ranked
ATS JSON > Recruiter CSV > Resume > GitHub > Recruiter notes — structured,
employer-entered data outranks self-reported prose, which outranks a
public API field that's often a self-chosen nickname. List fields
(emails, phones, skills): union + dedupe across ALL sources, never
collapsed to one winner, since a candidate can genuinely have multiple
real emails/phones. Confidence per field = source_base_confidence x
normalization_success + agreement_bonus (more independent sources
agreeing -> higher) - conflict_penalty (sources disagreed, a tie-break
was forced). `overall_confidence` = mean across populated fields.

## Runtime custom-output config

A stable internal `CanonicalProfile` is projected into whatever shape an
`OutputConfig` JSON requests at runtime — same engine, zero code changes,
via a DTO/projection layer (`Projector`). Supports field selection,
rename via `"from"` dotted/glob paths (e.g. `skills[].name`), per-field
normalize (E164 / canonical / ISO3166 — each independently idempotent,
re-normalizes defensively rather than trusting upstream state),
`required`, and `on_missing` (null / omit / error), both globally and
per-field. The projected output then passes a SECOND validation pass
(distinct from the pre-projection profile check) confirming the final
JSON actually satisfies the config's own `required`/`type` contract — a
profile being internally valid doesn't guarantee its projection is.

## Edge cases handled

(1) Cross-source phone/name conflicts (CSV/ATS/resume disagree on phone;
resume has a one-letter name typo) — resolved via source priority,
all phone variants preserved in the list output. (2) Phone with no
country code — parsed with a default region but confidence discounted,
never silently treated as fully certain. (3) A genuinely malformed/
missing source (garbage JSON, missing file) — caught by
`safe_extract()`, degrades to an empty source, pipeline completes with
whatever did parse; never crashes (verified end-to-end with a committed
garbage-input fixture). (4) GitHub rate-limit / API failure — degrades
immediately rather than blocking the pipeline (an earlier version slept
up to 60s and then never even retried — fixed). (5) Required-but-missing
output field — `on_missing: "error"` raises with a clear message instead
of silently shipping a null a downstream consumer marked as mandatory.

## Deliberately left out (time pressure)

LinkedIn (no public, ToS-compliant API — would mean scraping; better to
not ship a fragile/risky integration at all). Recruiter notes (free-text)
extractor — the source type and its confidence weight exist in the
taxonomy as a documented extension point, but no parser was implemented
under time pressure; CSV, ATS JSON, GitHub, and Resume were each fully
implemented and tested instead. Automatic cross-file identity resolution
(fuzzy-matching which files belong to the same candidate) — explicit
manifest/CLI flags used instead, since auto-matching is a separate, much
harder problem that works against this assignment's own "deterministic &
explainable" constraint.
