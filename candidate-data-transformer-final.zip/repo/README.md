# Multi-Source Candidate Data Transformer

Built for the Eightfold Engineering Intern (Jul-Dec 2026) assignment.

Reads candidate information from multiple, inconsistent sources and produces
one clean, canonical candidate profile -- deduplicated, normalized, with
provenance (where every value came from) and a confidence score per field.

> **Demo video:** _add your ~2 min screen recording link here before
> submitting._

---

## Quickstart

```bash
git clone https://github.com/Jashan1001/candidate-data-transformer.git
cd candidate-data-transformer

python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

pip install -r requirements.txt
pip install -e .                 # installs the `transformer` package + CLI

# Run end-to-end on the committed sample fixtures, default schema:
python -m transformer.cli \
  --csv input/recruiter.csv \
  --ats input/ats/sample.json \
  --resume input/resumes/priya_mehra_resume.pdf \
  --github octocat \
  --config input/configs/default.json \
  --output output/my_run.json

cat output/my_run.json
```

Every flag is optional except `--config`; supply any combination of
`--csv`, `--ats`, `--github`, `--resume` depending on which sources you have.
At least one source is required, or the run fails fast with a clear error.

### Run the test suite

```bash
pip install -r requirements.txt
pytest -q
```

108 tests, no network access required (GitHub calls are mocked in tests).

---

## What's actually in this repo

| Path | What it is |
|---|---|
| `src/transformer/` | the pipeline implementation (see Architecture below) |
| `input/recruiter.csv`, `input/ats/sample.json`, `input/resumes/*.pdf` | **synthetic fixtures** for a fictional candidate, "Priya Mehra" -- see [Fixtures](#fixtures-and-why-theyre-fictional) |
| `input/configs/default.json` | the assignment's fixed default output schema |
| `input/configs/custom_recruiter_view.json` | a second, genuinely different runtime config -- renames fields, normalizes phone/skills/country, marks two fields required |
| `input/garbage_example.json` | deliberately malformed JSON, committed so you can directly verify graceful degradation |
| `output/sample_output_*.json` | **real, committed output** from running the actual CLI against the fixtures above -- not hand-written (if GitHub's unauthenticated rate limit was exhausted at commit time, GitHub fields are correctly absent -- see [Robustness](#robustness)) |
| `docs/design.md` | the one-page Stage 1 design document |
| `tests/` | 108 tests across every module |

No sample inputs were provided with the assignment -- only the PDF spec
itself (confirmed by checking the linked Box folder). All fixtures above
were built deliberately to exercise normalization, conflict resolution,
provenance, confidence scoring, and graceful degradation -- see below.

---

## Fixtures, and why they're fictional

The fixtures use a fictional candidate, "Priya Mehra," with **intentional
conflicts across every source**, on purpose:

- **Phone numbers disagree across all three sources that report one** --
  CSV has a bare number with no country code (forces a lower-confidence,
  region-assumed E.164 conversion), ATS JSON has a different number
  entirely, and the resume has a third. All three survive into the final
  `phones` array (phones are deduplicated, not collapsed to one winner).
- **`years_experience` disagrees** between CSV (4) and ATS JSON (5) -- the
  merge engine has to pick a winner using source-priority, not just take
  whichever value showed up first.
- **The resume spells the name "Priya Mehraa"** (one letter off) -- a
  realistic typo/near-duplicate, not an exact string match, while CSV and
  ATS JSON agree on "Priya Mehra."
- **The GitHub fixture uses a real, public account (`octocat`)** rather
  than a fictional username, because the GitHub extractor makes a live API
  call -- there's no way to fixture a fake GitHub profile without mocking
  the network, and the assignment's own constraints section implies a real
  integration is expected. This creates a genuine, naturally-occurring
  identity conflict: GitHub reports `full_name = "The Octocat"`, totally
  unrelated to "Priya Mehra." This is left in deliberately -- it's exactly
  why GitHub sits at the *lowest* priority for identity fields (name) in
  `SOURCE_PRIORITY`, while still contributing real signal for skills and
  portfolio links (`github.blog`).

Run `output/sample_output_default.json` and `output/sample_output_custom.json`
side by side with the fixtures above to see exactly how each conflict was
resolved, including the `provenance` block, which records every source
that reported a value (`observed_sources`) and which one won.

---

## Architecture

```
        +----------+ +----------+ +----------+ +----------+
        |   CSV    | |   ATS    | |  GitHub  | |  Resume  |
        | Extractor| |  JSON    | | Extractor| | Extractor|
        |          | | Extractor| |          | |          |
        +----+-----+ +----+-----+ +----+-----+ +----+-----+
             |            |            |            |
             +------+-----+-----+------+-----+------+
                    |  RawCandidate per source |
                    v
             +---------------+
             |  Normalizers  |  (phone -> E.164, skill aliases -> canonical
             |               |   names, free-text location -> structured)
             +-------+-------+
                     v
             +---------------+
             |  Merge Engine |  conflict resolution by source priority,
             |               |  union+dedupe for list fields, provenance
             +-------+-------+
                     v
             +---------------+
             |  Confidence   |  per-field score: source trust + agreement
             |    Engine     |  across sources + normalization success
             +-------+-------+
                     v
             +---------------+
             |   Validator   |  sanity-check the internal CanonicalProfile
             | (pre-project) |
             +-------+-------+
                     v
             +---------------+
             |   Projector   |  apply runtime OutputConfig: select fields,
             |               |  rename via "from", per-field normalize
             +-------+-------+
                     v
             +---------------+
             |   Validator   |  check the FINAL JSON actually matches what
             |(post-project) |  the config asked for (required, type)
             +-------+-------+
                     v
                final JSON output
```

**Why extractors are dumb and isolated.** Each extractor (`CsvExtractor`,
`ATSJsonExtractor`, `GitHubExtractor`, `ResumeExtractor`) only knows how to
read its own format and produce a `RawCandidate` -- it has zero knowledge of
other sources, normalization rules, or conflict resolution. This is
Single Responsibility in practice: a bug in resume parsing can never
corrupt CSV parsing, and adding a fifth source type (e.g. LinkedIn,
recruiter notes -- see "What we scoped out" below) only means writing one
new class against the same `BaseExtractor` contract; nothing else changes.

**Why normalization happens before merge, not inside each extractor.**
If `CsvExtractor` and `ResumeExtractor` each normalized phone numbers
independently, you'd have two implementations that could disagree or have
different bugs. Pulling normalization into its own layer means every
source benefits from one correct implementation, and the merge engine
always compares already-normalized values -- it never has to guess whether
`"9876543210"` and `"+91 98765 43210"` are the same phone number.

**Why merge keeps every source's value, not just the winner, for list
fields.** Emails, phones, and skills are *unioned and deduplicated* across
sources, not collapsed to one winner -- a candidate plausibly has multiple
real emails/phones, and losing one because a different source reported a
different value first would be actively wrong. Scalar fields (full_name,
headline, years_experience, location) genuinely can only have one correct
value, so those go through source-priority conflict resolution instead.

**Why provenance records `observed_sources`, not just the winner.**
Confidence scoring rewards fields that multiple independent sources agree
on -- but if provenance only recorded the winning source, that agreement
signal would have nothing to read. `observed_sources` keeps every source
that reported *any* value for a field, even ones that lost the
conflict-resolution tie-break, so confidence can genuinely reflect
cross-source agreement.

**Why there are two validation passes, not one.** The first
(`validate_profile`, before projection) checks the internal canonical
record for basic sanity. The second (`validate_output`, after projection)
checks the *actual delivered JSON* against what the runtime config asked
for -- a bad rename path, a declared type the data doesn't match, or a
`required: true` field that should never have been allowed through as
`null`. A profile being internally valid doesn't guarantee its projection
is; these are genuinely separate concerns -- see `docs/design.md` for the
trade-off discussion.

**Confidence formula**, per field: `source_base_confidence x normalization_success
+ agreement_bonus (0, 0.05, or 0.10 depending on how many distinct sources
agreed) - conflict_penalty (when sources disagreed and a tie-break was
needed)`, clamped to `[0, 1]`. `overall_confidence` is the mean across all
populated fields. Source base confidence is ranked
`ATS JSON (0.95) > Recruiter CSV (0.85) > Resume (0.75) > GitHub (0.80) >
Recruiter notes (0.60)` -- structured, employer-entered data is trusted
most; free text least.

---

## Configurable output

The pipeline's internal canonical model never changes based on what the
caller asks for -- `Projector` reshapes a stable `CanonicalProfile` into
whatever JSON shape a runtime `OutputConfig` requests. This is the
DTO/projection pattern: the same engine produces the assignment's default
schema *and* a completely different, custom shape, from one config file,
with no code changes.

```bash
python -m transformer.cli \
  --csv input/recruiter.csv --ats input/ats/sample.json \
  --resume input/resumes/priya_mehra_resume.pdf --github octocat \
  --config input/configs/custom_recruiter_view.json \
  --output output/custom_run.json
```

See `input/configs/custom_recruiter_view.json` for an example exercising
field selection, `"from"` renaming, all three normalize strategies
(`E164`, `canonical`, `ISO3166`), `required: true`, and `on_missing`.

---

## Robustness

```bash
# Demonstrates graceful degradation on a malformed source:
python -m transformer.cli \
  --csv input/recruiter.csv --ats input/garbage_example.json \
  --config input/configs/default.json --output output/garbage_run.json
```

This exits cleanly (`exit code 0`) and produces a valid profile built from
whatever sources *did* parse -- see `output/sample_output_garbage_source.json`
for the actual committed result of this exact run. No source failure ever
crashes the pipeline; `BaseExtractor.safe_extract()` catches and logs, then
degrades to an empty source.

**Before recording your demo video, set a `GITHUB_TOKEN`.** GitHub's
*unauthenticated* API limit is 60 requests/hour, shared across anyone
running this on the same network -- it's easy to exhaust just from normal
development/testing (this happened while building this repo). If the
limit is exhausted, the pipeline still completes correctly with GitHub
data gracefully omitted -- itself a live demonstration of the robustness
requirement -- but for a clean recording showing all four sources
populated, generate a free token at
https://github.com/settings/tokens (no scopes needed for public data)
and export it first:

```bash
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx   # raises the limit to 5000/hour
python -m transformer.cli --github octocat ...
```

---

## What we deliberately scoped out

- **LinkedIn.** No public, ToS-compliant API exists for profile data;
  scraping it violates LinkedIn's terms. Rather than ship something
  fragile or risky, this is left as a documented extension point: adding
  it later only requires one new `BaseExtractor` subclass.
- **Recruiter notes (free text).** `SourceType.RECRUITER_NOTES` and its
  confidence weight already exist in the source taxonomy, but no
  extractor implements it -- scoped out under time pressure in favor of
  fully implementing and testing the other four sources.
- **Cross-file identity resolution (fuzzy-matching candidates across
  files automatically).** Every source for a run is assumed to belong to
  one candidate, supplied explicitly via CLI flags. Auto-matching
  candidates across files by fuzzy name/email similarity is a separate,
  much harder problem (what if two real candidates have similar names?)
  that has nothing to do with what this assignment actually tests, and
  would work against the "deterministic & explainable" constraint.
- **Experience/education parsing from resumes** works for clearly
  formatted sections but is regex-based and not bulletproof against
  unusual resume layouts -- a known, named limitation rather than a
  silent gap.

---

## Tech stack and why

- **Python 3.12** -- best-supported ecosystem for exactly this kind of
  data-wrangling/ETL problem.
- **`pydantic`** -- schema definition and validation for every internal
  model (`RawCandidate`, `CanonicalProfile`, `OutputConfig`); using it
  instead of hand-rolled dict validation is the kind of "use the right
  battle-tested tool" judgment this assignment explicitly rewards.
- **`phonenumbers`** (Google's libphonenumber) -- real E.164 phone
  normalization; hand-rolling international phone parsing correctly is a
  solved problem not worth re-solving.
- **`pdfplumber` / `python-docx`** -- PDF and DOCX text extraction for the
  resume extractor.
- **`requests`** -- GitHub REST API calls.
- **`pytest`** -- test suite (108 tests).

---

## Project layout

```
src/transformer/
+-- extractors/         one class per source type, isolated from each other
+-- normalizers/        one function per field type (phone, skill, location, date)
+-- merger/             conflict resolution + provenance
+-- confidence/         per-field confidence scoring
+-- projector/          runtime OutputConfig -> final JSON
+-- validator/          pre-projection AND post-projection validation
+-- models/             RawCandidate, CanonicalProfile, OutputConfig (pydantic)
+-- utils/              deep_get/deep_set, structured logger
+-- main.py             CandidateTransformer -- orchestrates the full pipeline
+-- cli.py              thin argparse wrapper around main.py
```

See `docs/design.md` for the Stage 1 one-page design document (pipeline
breakdown, canonical schema, merge/conflict policy, custom-config handling,
edge cases, and what was deliberately left out under time pressure).
